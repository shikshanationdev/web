import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { ShikshaNationAbout } from "./screens/ShikshaNationAbout";

createRoot(document.getElementById("app") as HTMLElement).render(
  <StrictMode>
    <ShikshaNationAbout />
  </StrictMode>,
);
