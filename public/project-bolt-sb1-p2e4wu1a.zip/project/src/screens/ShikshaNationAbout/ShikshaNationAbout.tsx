import React from "react";
import { Card, CardContent } from "../../components/ui/card";
import { AboutUsSection } from "./sections/AboutUsSection";
import { AdvantagesSection } from "./sections/AdvantagesSection";
import { AffiliationsSection } from "./sections/AffiliationsSection/AffiliationsSection";
import { ContactUsSection } from "./sections/ContactUsSection";
import { FooterSection } from "./sections/FooterSection";
import { HeroSection } from "./sections/HeroSection";
import { LearnerTestimonialsSection } from "./sections/LearnerTestimonialsSection";
import { ManagementTeamSection } from "./sections/ManagementTeamSection";
import { MissionSection } from "./sections/MissionSection";

export const ShikshaNationAbout = (): JSX.Element => {
  // Management team data for mapping
  const managementTeam = [
    {
      name: "Rajat Sharma",
      position: "Chief Business Officer (CBO)",
      image: "/rectangle-6751.png",
      borderColor: "border-[#0169b6]",
      bgColor: "bg-[#e0f1ff]",
    },
    {
      name: "Gaurav Mittal",
      position: "Chief Technology & HR Officer (CTO & HR Head)",
      image: "/rectangle-6752.png",
      borderColor: "border-[#68ba4c]",
      bgColor: "bg-[#e8ffe0]",
    },
    {
      name: "Anurag Mishra",
      position: "Vice President, Academics",
      image: "/rectangle-6753.png",
      borderColor: "border-[#0169b6]",
      bgColor: "bg-[#e0f1ff]",
    },
    {
      name: "Dr. NKS",
      position: "Vice President, Academics (Biology & NEET)",
      image: "/rectangle-6754.png",
      borderColor: "border-[#68ba4c]",
      bgColor: "bg-[#e8ffe0]",
    },
  ];

  return (
    <div className="bg-white flex flex-col items-center w-full min-h-screen">
      <div className="bg-white overflow-hidden w-full max-w-[1440px] relative">
        {/* Hero Section */}
        <HeroSection />

        {/* Decorative elements */}
        <img
          className="absolute w-10 h-10 top-[389px] left-[216px]"
          alt="Star"
          src="/star-8.svg"
        />
        <img
          className="absolute w-10 h-10 top-[227px] left-[1016px]"
          alt="Star"
          src="/star-9.svg"
        />

        <div className="absolute w-20 h-20 top-[250px] left-[255px] bg-white rounded-[40px] border border-solid border-[#3ec3a4]">
          <img
            className="absolute w-14 h-14 top-[11px] left-[11px]"
            alt="Frame"
            src="/frame-2.svg"
          />
        </div>

        <div className="absolute w-20 h-20 top-[448px] left-[334px] bg-white rounded-[40px] border border-solid border-[#cb97e7]">
          <img
            className="absolute w-14 h-14 top-[11px] left-[11px]"
            alt="Frame"
            src="/frame.svg"
          />
        </div>

        <img
          className="absolute w-20 h-20 top-[418px] left-[1044px]"
          alt="Frame"
          src="/frame-1116607688.svg"
        />

        <img
          className="absolute w-20 h-20 top-[273px] left-[1132px]"
          alt="Frame"
          src="/frame-1116607687.svg"
        />

        {/* Decorative circles */}
        <div className="absolute w-[306px] h-[306px] top-[365px] left-[1220px] rounded-[153px] border-[5px] border-solid border-[#68ba4c]">
          <div className="relative w-[262px] h-[262px] top-[17px] left-[17px] bg-[#ff9e4a] rounded-[131px]" />
        </div>

        <div className="absolute w-[306px] h-[306px] top-[159px] left-[-197px] rounded-[153px] border-[5px] border-solid border-[#0169b6]">
          <div className="relative w-[262px] h-[262px] top-[15px] left-[17px] bg-[#ff9e4a] rounded-[131px]" />
        </div>

        {/* About Us Section */}
        <AboutUsSection />

        {/* Mission Section */}
        <MissionSection />

        {/* Management Team Section */}
        <div className="w-full flex flex-col items-center mt-20">
          <h2 className="font-['Lexend_Deca',Helvetica] font-bold text-[#141219] text-[40px] text-center mb-4">
            Meet Our Management Team
          </h2>

          <p className="w-full max-w-[689px] font-['Lexend_Deca',Helvetica] font-normal text-[#454648] text-lg text-center mb-12">
            The minds behind Shiksha Nation — leading with vision, passion, and
            purpose.
          </p>

          <div className="flex flex-wrap justify-center gap-8">
            {managementTeam.map((member, index) => (
              <Card
                key={index}
                className={`w-60 h-80 rounded-xl overflow-hidden ${member.borderColor} border border-solid`}
              >
                <CardContent className="p-0 h-full relative">
                  <div className="absolute w-[332px] h-[393px] top-[-223px] left-[-46px]">
                    <div
                      className={`absolute w-[332px] h-[332px] top-0 left-0 ${member.bgColor} rounded-[166px]`}
                    />
                    <img
                      className="absolute w-[143px] h-[143px] top-[250px] left-[95px] object-cover"
                      alt={member.name}
                      src={member.image}
                    />
                  </div>

                  <div className="absolute top-[197px] left-0 right-0 font-['Lexend_Deca',Helvetica] font-bold text-black text-xl text-center">
                    {member.name}
                  </div>

                  <div className="absolute w-[206px] top-[230px] left-1/2 -translate-x-1/2 font-['Lexend_Deca',Helvetica] font-normal text-black text-base text-center">
                    {member.position}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <ManagementTeamSection />

        {/* Affiliations Section */}
        <AffiliationsSection />

        {/* Advantages Section */}
        <AdvantagesSection />

        {/* Learner Testimonials Section */}
        <LearnerTestimonialsSection />

        {/* Contact Us Section */}
        <ContactUsSection />

        {/* Footer Section */}
        <FooterSection />
      </div>
    </div>
  );
};
