import { ChevronDownIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "../../../../components/ui/navigation-menu";

export const HeroSection = (): JSX.Element => {
  // Navigation menu items data
  const navItems = [
    { text: "Home", href: "#", active: true },
    { text: "About Us", href: "#", active: false },
    { text: "Courses", href: "#", hasDropdown: true, active: false },
    { text: "Contact us", href: "#", active: false },
  ];

  return (
    <header className="w-full h-[120px] bg-white border-b border-[#98d0fa] flex items-center justify-between px-28">
      {/* Logo */}
      <div className="flex-shrink-0">
        <img
          className="w-[183px] h-[54px] object-cover"
          alt="Shiksha Nation Logo"
          src="/05b99715f32c973f929cd22735389966-1-1.png"
        />
      </div>

      {/* Navigation */}
      <NavigationMenu className="mx-auto">
        <NavigationMenuList className="flex gap-16">
          {navItems.map((item, index) => (
            <NavigationMenuItem key={index}>
              <NavigationMenuLink
                href={item.href}
                className={`flex items-center [font-family:'Inter',Helvetica] font-normal text-lg ${
                  item.active ? "text-endeavour" : "text-[#141219]"
                }`}
              >
                {item.text}
                {item.hasDropdown && (
                  <ChevronDownIcon className="ml-2 h-[18px] w-[18px]" />
                )}
              </NavigationMenuLink>
            </NavigationMenuItem>
          ))}
        </NavigationMenuList>
      </NavigationMenu>

      {/* Auth Buttons */}
      <div className="flex gap-6">
        <Button
          variant="outline"
          className="w-[130px] h-[48px] rounded-[80px] border-[#0169b6] [font-family:'Inter',Helvetica] font-normal text-endeavour text-lg"
        >
          Login
        </Button>
        <Button className="w-[130px] h-[48px] rounded-[80px] bg-endeavour [font-family:'Inter',Helvetica] font-normal text-white text-lg">
          Sign up
        </Button>
      </div>
    </header>
  );
};
