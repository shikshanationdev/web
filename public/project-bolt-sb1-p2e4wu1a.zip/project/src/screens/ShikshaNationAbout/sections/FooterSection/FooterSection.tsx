import { ArrowRightIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import { Separator } from "../../../../components/ui/separator";

export const FooterSection = (): JSX.Element => {
  // Stats data
  const stats = [
    { value: "6.3k", label: "Online courses" },
    { value: "26k", label: "Certified Instructor" },
    { value: "99.9%", label: "Sucess Rate" },
  ];

  // Category links data
  const categoryLinks = [
    "Class 6",
    "Class 7",
    "Class 8",
    "Class 9",
    "Class 10",
    "Test Series",
  ];

  // Useful links data
  const usefulLinks = [
    { name: "FAQs", hasArrow: false },
    { name: "Become Instructor", hasArrow: true },
    { name: "Privacy Policy", hasArrow: false },
    { name: "Terms & Conditions", hasArrow: false },
    { name: "Refund Policy", hasArrow: false },
  ];

  // Company links data
  const companyLinks = ["About Us", "Blog", "Media", "Career", "Contact Us"];

  return (
    <footer className="w-full bg-white py-16 px-4 md:px-8 lg:px-16">
      <div className="container mx-auto">
        {/* Top section with CTA and stats */}
        <div className="flex flex-col lg:flex-row gap-8 justify-between">
          {/* Left side with heading and buttons */}
          <div className="flex flex-col gap-8 max-w-lg">
            <h2 className="text-endeavour text-[40px] tracking-[-0.40px] [font-family:'Lexend_Deca',Helvetica] font-semibold leading-[48px]">
              Start learning with 67.1k students around the world.
            </h2>

            <div className="flex flex-wrap items-center gap-4">
              <Button className="bg-mantis rounded-[50px] h-12 px-6 [font-family:'Lexend_Deca',Helvetica] font-semibold text-graywhite">
                Start Learning Now
              </Button>

              <Button
                variant="outline"
                className="bg-[#68ba4c0d] border-none rounded-[50px] h-12 px-6 [font-family:'Lexend_Deca',Helvetica] font-semibold text-[#68ba4c]"
              >
                Browse All Courses
              </Button>
            </div>
          </div>

          {/* Right side with stats */}
          <div className="flex gap-8 lg:gap-16">
            {stats.map((stat, index) => (
              <div key={index} className="flex flex-col">
                <span className="[font-family:'Lexend_Deca',Helvetica] font-semibold text-endeavour text-[40px] tracking-[-0.40px] leading-[48px]">
                  {stat.value}
                </span>
                <span className="[font-family:'Lexend_Deca',Helvetica] font-medium text-endeavour text-base leading-[22px]">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Middle section with logo, contact info, and links */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and contact info */}
          <div className="flex flex-col gap-6">
            <img
              className="w-56 h-[66px] object-cover"
              alt="Shiksha Nation Logo"
              src="/05b99715f32c973f929cd22735389966-1-1.png"
            />

            <div className="[font-family:'Lexend_Deca',Helvetica] text-base">
              <p className="mb-4">
                <span className="font-semibold text-[#0169b6]">
                  Corporate Office:
                </span>{" "}
                <span className="text-[#2f8acd]">
                  10th Floor, Tower C, Bhutani 62 Avenue, Block-c, Phase 2,
                  Noida, Up 201309
                </span>
              </p>

              <p className="mb-2">
                <span className="font-semibold text-[#0169b6]">Call:</span>{" "}
                <span className="text-[#2f8acd]">+91 98211 15117</span>
              </p>

              <p className="mb-4">
                <span className="font-semibold text-[#0169b6]">Email:</span>{" "}
                <span className="text-[#2f8acd]">hello@shikshanation.in</span>
              </p>
            </div>

            <div className="flex">
              <img className="h-8" alt="Social media" src="/social-media.svg" />
            </div>
          </div>

          {/* Top Categories */}
          <div className="flex flex-col gap-4">
            <h3 className="[font-family:'Lexend_Deca',Helvetica] font-semibold text-[#0169b6] text-sm leading-[14px]">
              Top Categories
            </h3>
            <div className="flex flex-col">
              {categoryLinks.map((category, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="justify-start p-0 h-10 [font-family:'Lexend_Deca',Helvetica] font-normal text-[#1d7cc2] text-sm tracking-[-0.14px] hover:bg-transparent hover:text-[#0169b6]"
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Useful Links */}
          <div className="flex flex-col gap-4">
            <h3 className="[font-family:'Lexend_Deca',Helvetica] font-semibold text-[#0169b6] text-sm leading-[14px]">
              Useful Links
            </h3>
            <div className="flex flex-col">
              {usefulLinks.map((link, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="justify-start p-0 h-10 [font-family:'Lexend_Deca',Helvetica] font-normal text-[#1d7cc2] text-sm tracking-[-0.14px] hover:bg-transparent hover:text-[#0169b6]"
                >
                  {link.name}
                  {link.hasArrow && (
                    <ArrowRightIcon className="ml-1.5 h-4 w-4" />
                  )}
                </Button>
              ))}
            </div>
          </div>

          {/* Company */}
          <div className="flex flex-col gap-4">
            <h3 className="[font-family:'Lexend_Deca',Helvetica] font-semibold text-[#0169b6] text-sm leading-[14px]">
              Company
            </h3>
            <div className="flex flex-col">
              {companyLinks.map((link, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="justify-start p-0 h-10 [font-family:'Lexend_Deca',Helvetica] font-normal text-[#1d7cc2] text-sm tracking-[-0.14px] hover:bg-transparent hover:text-[#0169b6]"
                >
                  {link}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer bottom with copyright */}
        <div className="mt-16">
          <Separator className="mb-6" />
          <div className="flex flex-col items-center gap-2 text-center">
            <p className="[font-family:'Lexend_Deca',Helvetica] font-semibold text-[#1d7cc2] text-sm">
              © 2025 All Rights Reserved.
            </p>
            <p className="[font-family:'Lexend_Deca',Helvetica] text-[#1d7cc2] text-sm">
              <span className="font-semibold">Shiksha Nation™ </span>
              is completely owned &amp; operated by
              <span className="font-semibold">
                {" "}
                Rarepillar Education Services Private Limited
              </span>
            </p>
            <p className="[font-family:'Lexend_Deca',Helvetica] text-[#1d7cc2] text-sm">
              Designed by
              <span className="font-semibold"> Generative Crafts</span>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};
