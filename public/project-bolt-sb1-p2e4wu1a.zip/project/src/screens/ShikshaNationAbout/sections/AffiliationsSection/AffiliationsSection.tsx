import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const AffiliationsSection = (): JSX.Element => {
  // Data for affiliation cards
  const affiliationCards = [
    {
      id: 1,
      image: "/msme-1.png",
      imageWidth: "w-[135px]",
      imageHeight: "h-[126px]",
      imageTop: "top-0",
      imageLeft: "left-[72px]",
      label: "MSME Registered",
      labelLeft: "left-[71px]",
      cardWidth: "w-[278px]",
      cardHeight: "h-[156px]",
      cardTop: "top-0",
      cardLeft: "left-0",
    },
    {
      id: 2,
      image: "/images--3--1.png",
      imageWidth: "w-[131px]",
      imageHeight: "h-[98px]",
      imageTop: "top-[18px]",
      imageLeft: "left-[74px]",
      label: "ISO : Certified",
      labelLeft: "left-[84px]",
      cardWidth: "w-[278px]",
      cardHeight: "h-[165px]",
      cardTop: "top-[186px]",
      cardLeft: "left-[150px]",
    },
    {
      id: 3,
      image: "/startup-india-2-1.png",
      imageWidth: "w-[139px]",
      imageHeight: "h-20",
      imageTop: "top-1.5",
      imageLeft: "left-[7px]",
      label: "Recognized by Startup India",
      labelLeft: "left-11",
      labelSize: "text-sm",
      cardWidth: "w-[284px]",
      cardHeight: "h-[156px]",
      cardTop: "top-0",
      cardLeft: "left-[307px]",
      hasBackground: true,
    },
  ];

  return (
    <section className="relative w-full h-[507px] flex justify-center items-center">
      <div className="flex flex-row max-w-[1440px] w-full">
        <div className="flex flex-col items-start gap-5 ml-[216px] w-[368px]">
          <h2 className="[font-family:'Lexend_Deca',Helvetica] font-semibold text-gray-900 text-[40px] tracking-[-0.40px] leading-10">
            Our Affiliations &amp; Certifications
          </h2>
          <p className="[font-family:'Lexend_Deca',Helvetica] font-normal text-[#6e7484] text-base tracking-[0] leading-6">
            Shiksha Nation is proud to be affiliated with leading education
            boards, institutions, and certified learning partners
          </p>
        </div>

        <div className="relative w-[591px] h-[351px] ml-[101px]">
          {affiliationCards.map((card) => (
            <Card
              key={card.id}
              className={`absolute ${card.cardWidth} ${card.cardHeight} ${card.cardTop} ${card.cardLeft} bg-graywhite rounded-3xl overflow-hidden shadow-[0px_0px_32px_#68ba4c26]`}
            >
              <CardContent className="p-0 h-full relative">
                {card.hasBackground ? (
                  <div className="absolute w-[153px] h-[92px] top-[21px] left-[66px] bg-[#273e4e] rounded-lg">
                    <img
                      className={`absolute ${card.imageWidth} ${card.imageHeight} ${card.imageTop} ${card.imageLeft} object-cover`}
                      alt={card.label}
                      src={card.image}
                    />
                  </div>
                ) : (
                  <img
                    className={`absolute ${card.imageWidth} ${card.imageHeight} ${card.imageTop} ${card.imageLeft} ${card.id === 2 ? "object-cover" : ""}`}
                    alt={card.label}
                    src={card.image}
                  />
                )}
                <div
                  className={`absolute w-full ${card.id === 3 ? "top-[126px]" : card.id === 2 ? "top-[135px]" : "top-[122px]"} h-[30px] left-0 bg-[#efffea]`}
                >
                  <div
                    className={`absolute top-${card.id === 3 ? "[5px]" : "1"} ${card.labelLeft} [font-family:'Lexend_Deca',Helvetica] font-normal text-[#477f34] ${card.labelSize || "text-base"} text-center tracking-[0] leading-[normal]`}
                  >
                    {card.label}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
