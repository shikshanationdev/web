import { ArrowUpRightIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";

export const ContactUsSection = (): JSX.Element => {
  return (
    <section className="w-full bg-[#1b283f] py-16 relative">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl">
          <p className="font-['Lexend_Deca',Helvetica] font-light text-white text-2xl mb-4">
            GET IN TOUCH
          </p>

          <h2 className="font-['Lexend_Deca',Helvetica] font-bold text-white text-[40px] mb-10">
            For Queries, Feedback or Assistance
          </h2>

          <Button className="bg-mantis hover:bg-mantis/90 text-white rounded-[80px] px-11 py-4 h-auto">
            <span className="font-['Lexend_Deca',Helvetica] text-2xl">
              Contact Us
            </span>
            <ArrowUpRightIcon className="ml-2.5 w-9 h-8" />
          </Button>
        </div>
      </div>

      <img
        className="absolute w-[292px] h-[310px] top-0 right-0"
        alt="Decorative element"
        src="/rh-ne.svg"
      />
    </section>
  );
};
