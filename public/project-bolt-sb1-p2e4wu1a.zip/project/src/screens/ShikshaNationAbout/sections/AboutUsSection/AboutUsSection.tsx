import React from "react";
import { Separator } from "../../../../components/ui/separator";

export const AboutUsSection = (): JSX.Element => {
  return (
    <section className="relative w-full max-w-[1061px] mx-auto py-16">
      <h2 className="text-center font-bold text-[40px] text-[#141219] font-['Lexend_Deca',Helvetica] mb-10">
        Who We Are
      </h2>

      <div className="flex flex-col gap-8">
        <div className="flex items-center justify-between">
          <div className="relative">
            <img
              className="w-[318px] h-[378px] object-cover"
              alt="Students learning"
              src="/rectangle-6731.png"
            />
            <Separator
              className="absolute left-0 top-[214px] h-[214px] w-[1px] bg-gradient-to-b from-mantis to-transparent ml-[-62px]"
              orientation="vertical"
            />
          </div>

          <div className="flex flex-col">
            <Separator className="w-[354px] h-[1px] mb-10 bg-gradient-to-r from-endeavour to-transparent" />
            <p className="w-[678px] font-medium text-2xl font-['Lexend_Deca',Helvetica] bg-gradient-to-b from-endeavour to-[#2F91D9] bg-clip-text text-transparent">
              At Siksha Nation, we believe that education is the foundation of
              national progress. Our bilingual, inclusive, and technology-driven
              platform bridges urban-rural gaps, offering personalized learning
              experiences that are both academically rigorous and future-ready.
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between mt-8">
          <div className="flex flex-col mr-16">
            <p className="w-[406px] font-medium text-2xl text-right font-['Lexend_Deca',Helvetica] bg-gradient-to-b from-mantis to-[#94D47E] bg-clip-text text-transparent">
              Through live classes, smart notes, skilling programs, and exam
              prep, we empower students from Class 6 to 12 and beyond to achieve
              excellence — not just in marks, but in life.
              <br />
              <br />
              We&apos;re building a nation of confident learners,
              problem-solvers, and dreamers who are ready to lead tomorrow.
            </p>
          </div>

          <div className="relative">
            <img
              className="w-[318px] h-[378px] object-cover"
              alt="Educational environment"
              src="/rectangle-6732.png"
            />
            <Separator
              className="absolute right-0 top-[-23px] h-[284px] w-[1px] bg-gradient-to-b from-mantis to-transparent mr-[-52px]"
              orientation="vertical"
            />
          </div>
        </div>
      </div>

      <Separator className="w-[388px] h-[1px] mt-16 ml-auto bg-gradient-to-r from-transparent to-mantis" />

      <div className="absolute w-[178px] h-[178px] top-[385px] left-[375px] rounded-[89px] bg-[radial-gradient(50%_50%_at_50%_50%,rgba(104,186,76,1)_0%,rgba(255,255,255,0)_100%)]" />
    </section>
  );
};
