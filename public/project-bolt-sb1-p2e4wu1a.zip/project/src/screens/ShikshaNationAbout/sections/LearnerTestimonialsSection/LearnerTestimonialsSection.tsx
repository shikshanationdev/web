import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const LearnerTestimonialsSection = (): JSX.Element => {
  // Testimonial data for mapping
  const testimonials = [
    {
      quote:
        "Shiksha Nation made Science and Maths so easy for me! The lessons are fun, and I love how I can revise anytime. My marks improved in just one term!",
      author: "Ananya Sharma",
      iconSrc: "/vector.svg",
      ratingSrc: "/frame-162927.svg",
    },
    {
      quote:
        "As a parent, I was looking for a platform that's both reliable and easy to monitor. Shiksha Nation gave my son structured classes, progress reports, and expert support — we're very happy!",
      author: "Ravi Mehta",
      iconSrc: "/vector.svg",
      ratingSrc: "/frame-162927.svg",
    },
    {
      quote:
        "Preparing for NEET felt overwhelming until I joined Shiksha Nation. The mock tests, doubt-solving sessions, and mentors really helped me stay focused and confident.",
      author: "Mehul Raj",
      iconSrc: "/vector.svg",
      ratingSrc: "/frame-162927.svg",
    },
  ];

  return (
    <section className="w-full py-28 bg-white">
      <div className="flex flex-col items-center gap-11 max-w-[1238px] mx-auto">
        <div className="flex flex-col items-center gap-[60px]">
          <header className="flex flex-col items-center gap-3">
            <h2 className="w-full max-w-[704px] [font-family:'Lexend_Deca',Helvetica] font-bold text-[#0d1216] text-[40px] text-center leading-[48px]">
              What Our Learners Say
            </h2>
            <p className="[font-family:'Lexend_Deca',Helvetica] font-normal text-[#313c44] text-lg text-center leading-8">
              Thousands of students and parents trust Shiksha Nation for quality
              learning.
            </p>
          </header>

          <div className="flex flex-wrap justify-center gap-8">
            {testimonials.map((testimonial, index) => (
              <Card
                key={index}
                className="w-[385px] rounded-xl shadow-4-8 bg-color-palettewhite-background"
              >
                <CardContent className="p-[30px]">
                  <div className="flex flex-col items-start gap-5">
                    <img
                      className="w-10 h-[30px]"
                      alt="Quote icon"
                      src={testimonial.iconSrc}
                    />
                    <div className="flex flex-col items-start gap-6 w-full">
                      <p className="[font-family:'Quicksand',Helvetica] font-medium text-[#0d1216] text-lg tracking-[0.09px] leading-[27px]">
                        {testimonial.quote}
                      </p>
                    </div>
                    <div className="flex items-center justify-between w-full">
                      <h3 className="[font-family:'Quicksand',Helvetica] font-bold text-[#0d1216] text-lg leading-[25px]">
                        {testimonial.author}
                      </h3>
                      <img
                        className="flex-shrink-0"
                        alt="Rating stars"
                        src={testimonial.ratingSrc}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
