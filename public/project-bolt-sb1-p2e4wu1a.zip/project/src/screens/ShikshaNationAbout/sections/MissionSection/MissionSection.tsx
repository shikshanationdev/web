import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const MissionSection = (): JSX.Element => {
  return (
    <section className="w-full max-w-[1215px] mx-auto my-8">
      <div className="flex flex-row">
        {/* Mission Card */}
        <Card className="w-1/2 h-[282px] bg-[#0169b6] rounded-[34px_0px_0px_34px] border-none relative before:content-[''] before:absolute before:inset-0 before:p-0.5 before:rounded-[34px_0px_0px_34px] before:[background:linear-gradient(102deg,rgba(255,255,255,1)_0%,rgba(1,105,182,1)_100%)] before:[-webkit-mask:linear-gradient(#fff_0_0)_content-box,linear-gradient(#fff_0_0)] before:[-webkit-mask-composite:xor] before:[mask-composite:exclude] before:z-[1] before:pointer-events-none">
          <CardContent className="p-0 h-full flex flex-col items-center justify-center">
            <div className="flex items-center justify-center mb-4">
              <img
                className="w-[30px] h-[30px] mr-3"
                alt="Mission icon"
                src="/frame-1.svg"
              />
              <h2 className="font-['Lexend_Deca',Helvetica] font-bold text-white text-[32px]">
                Our Mission
              </h2>
            </div>
            <p className="w-[510px] mx-auto font-['Lexend_Deca',Helvetica] font-medium text-white text-xl">
              To make high-quality, affordable education accessible to every
              learner in India — blending academic success with career
              readiness, and building a self-reliant, skilled Bharat.
            </p>
          </CardContent>
        </Card>

        {/* Vision Card */}
        <Card className="w-1/2 h-[282px] bg-[#68ba4c] rounded-[0px_34px_34px_0px] border-none relative before:content-[''] before:absolute before:inset-0 before:p-0.5 before:rounded-[0px_34px_34px_0px] before:[background:linear-gradient(258deg,rgba(255,255,255,1)_0%,rgba(104,186,76,1)_100%)] before:[-webkit-mask:linear-gradient(#fff_0_0)_content-box,linear-gradient(#fff_0_0)] before:[-webkit-mask-composite:xor] before:[mask-composite:exclude] before:z-[1] before:pointer-events-none">
          <CardContent className="p-0 h-full flex flex-col items-center justify-center">
            <div className="flex items-center justify-center mb-4">
              <h2 className="font-['Lexend_Deca',Helvetica] font-bold text-white text-[32px]">
                Our Vision
              </h2>
              <img
                className="w-9 h-9 ml-3"
                alt="Vision icon"
                src="/frame-3.svg"
              />
            </div>
            <p className="w-[510px] mx-auto font-['Lexend_Deca',Helvetica] font-medium text-white text-xl text-right">
              To be India&apos;s most trusted learning platform, uniting school
              education, entrance preparation, and skill development under one
              digital roof — and creating a generation of future-ready citizens
              who thrive in a global economy.
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};
