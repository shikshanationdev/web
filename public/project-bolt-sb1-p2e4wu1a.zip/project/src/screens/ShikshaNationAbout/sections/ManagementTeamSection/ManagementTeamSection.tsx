import React from "react";

export const ManagementTeamSection = (): JSX.Element => {
  // Data for statistics to enable mapping
  const statistics = [
    {
      value: "25k",
      label: "Students",
      width: "w-[108px]",
      position: "ml-[209px]",
    },
    {
      value: "6k",
      label: "Enrolled Learners",
      width: "w-[216px]",
      position: "ml-[87px]",
    },
    {
      value: "11+",
      label: "Expert Instructors",
      width: "w-[226px]",
      position: "ml-[87px]",
    },
    {
      value: "96%",
      label: "Satisfaction Rate",
      width: "w-[210px]",
      position: "ml-[87px]",
    },
  ];

  return (
    <section className="w-full h-[158px] bg-white py-2.5 flex justify-center">
      <div className="flex items-start">
        {statistics.map((stat, index) => (
          <div
            key={`stat-${index}`}
            className={`flex flex-col ${stat.width} items-center gap-2 ${index === 0 ? stat.position : stat.position}`}
          >
            <div className="relative self-stretch mt-[-1.00px] [font-family:'Lexend_Deca',Helvetica] font-extralight text-[#141219] text-[64px] text-center tracking-[0] leading-[normal]">
              {stat.value}
            </div>
            <div className="relative self-stretch [font-family:'Lexend_Deca',Helvetica] font-bold text-endeavour text-2xl tracking-[0] leading-[normal]">
              {stat.label}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
