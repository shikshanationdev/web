import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const AdvantagesSection = (): JSX.Element => {
  const advantageCards = [
    {
      title: "Certified, Job-Ready Courses",
      description:
        "Each course is designed with industry-aligned skills and ends with a recognized certificate to boost your career opportunities.",
      bgColor: "bg-[#e5f4ff]",
      textColor: "text-endeavour",
      icon: "/elearning-6991765-1.png",
      iconAlt: "Elearning",
      iconWidth: "w-[69px]",
      iconHeight: "h-[69px]",
      iconClass: "object-cover",
    },
    {
      title: "Unlimited Lifetime Access",
      description:
        "Learn at your pace, revisit lessons anytime, and continue to grow — even years after enrolling. Your access never expires.",
      bgColor: "bg-[#e8ffe0]",
      textColor: "text-mantis",
      icon: "/infinite.svg",
      iconAlt: "Infinite",
      iconWidth: "w-[72px]",
      iconHeight: "h-9",
      iconClass: "",
    },
    {
      title: "Top Mentors & Live Support",
      description:
        "Our expert instructors and live student support ensure you're never stuck — help and guidance are always a message away.",
      bgColor: "bg-[#e5f4ff]",
      textColor: "text-endeavour",
      icon: "/graduate-12571819-1.png",
      iconAlt: "Graduate",
      iconWidth: "w-[69px]",
      iconHeight: "h-[69px]",
      iconClass: "object-cover",
    },
  ];

  return (
    <section className="w-full py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center mb-12">
          <h3 className="font-normal text-2xl text-[#141219] text-center [font-family:'Lexend_Deca',Helvetica]">
            Why Choose Shiksha Nation
          </h3>
          <h2 className="font-bold text-[40px] text-black text-center [font-family:'Lexend_Deca',Helvetica] max-w-[655px] mt-2">
            Unlock the Powerful Advantages of Learning with Us
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-[1100px] mx-auto">
          {advantageCards.map((card, index) => (
            <Card
              key={index}
              className={`${card.bgColor} border-none rounded-xl h-[310px] relative`}
            >
              <CardContent className="p-8 h-full flex flex-col">
                <h3
                  className={`${card.textColor} text-2xl font-medium [font-family:'Lexend_Deca',Helvetica] mb-6`}
                >
                  {card.title}
                </h3>
                <p
                  className={`${card.textColor} text-base font-light [font-family:'Lexend_Deca',Helvetica]`}
                >
                  {card.description}
                </p>
                <div className="mt-auto">
                  <img
                    className={`${card.iconWidth} ${card.iconHeight} ${card.iconClass}`}
                    alt={card.iconAlt}
                    src={card.icon}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
